
var soundFile = new Audio("http://static1.grsites.com/archive/sounds/cartoon/cartoon007.wav");


function playSound() {
    var soundFile = new Audio("http://static1.grsites.com/archive/sounds/cartoon/cartoon004.wav");
    soundFile.play();
}



function shuffle() {
var randomnumber3 = Math.ceil(Math.random() * 500);
    document.getElementbyId("score-box").innerHTML = randomnumber3;
    var idk = document.getElementById("buttons2").disabled = true;

}




function bomb() {
document.getElementById("score-box").innerHTML = 0;


}

function x2() { 
var scorebox = Number(document.getElementById("score-box").innerHTML); 
     
    var multiply2 = scorebox*2;
    document.getElementById("score-box").innerHTML = multiply2;
}





function spin13() {
    var randomnumber13 = Math.ceil(Math.random() * 12);
    
    numberbox1.innerHTML = randomnumber13;
    

   
}




function spin() {
document.getElementById("buttons").innerHTML = eval(Math.floor(Math.random() * 100));



document.getElementById("buttons1").innerHTML = eval(Math.floor(Math.random() * 100));




document.getElementById("buttons3").innerHTML = eval(Math.floor(Math.random() * 100));



document.getElementById("buttons4").innerHTML = eval(Math.floor(Math.random() * 100));



document.getElementById("buttons5").innerHTML = eval(Math.floor(Math.random() * 100));


document.getElementById("buttons6").innerHTML = eval(Math.floor(Math.random() * 100));
    
    
document.getElementById("buttons8").innerHTML = eval(Math.floor(Math.random() * 100));
    
    document.getElementById("buttons10").innerHTML = eval(Math.floor(Math.random() * 100));
    
    document.getElementById("buttons11").innerHTML = eval(Math.floor(Math.random() * 100));

 document.getElementById("score-box").innerHTML = 0;

    
    var idk = document.getElementById("spin").disabled = true;

}


function niggaz() { 
document.getElementById("numberbox").innerHTML = eval(Math.floor(Math.random() * 12));
}
    
function addition1() {
 var scorebox = Number(document.getElementById("score-box").innerHTML); 
     var button1 = Number(document.getElementById("buttons").innerHTML); 
    var additionBruh1 = scorebox + button1;
    document.getElementById("score-box").innerHTML = additionBruh1;
}

function addition2() {
 var scorebox = Number(document.getElementById("score-box").innerHTML); 
     var button2 = Number(document.getElementById("buttons1").innerHTML); 
    var additionBruh2 = scorebox + button2;
    document.getElementById("score-box").innerHTML = additionBruh2;
}

function addition4() {
 var scorebox = Number(document.getElementById("score-box").innerHTML); 
     var button4 = Number(document.getElementById("buttons3").innerHTML); 
    var additionBruh4 = scorebox + button4;
    document.getElementById("score-box").innerHTML = additionBruh4;
}

function addition5() {
 var scorebox = Number(document.getElementById("score-box").innerHTML); 
     var button5 = Number(document.getElementById("buttons4").innerHTML); 
    var additionBruh5 = scorebox + button5;
    document.getElementById("score-box").innerHTML = additionBruh5;
}

function addition6() {
 var scorebox = Number(document.getElementById("score-box").innerHTML); 
     var button6 = Number(document.getElementById("buttons5").innerHTML); 
    var additionBruh6 = scorebox + button6;
    document.getElementById("score-box").innerHTML = additionBruh6;
}

function addition7() {
 var scorebox = Number(document.getElementById("score-box").innerHTML); 
     var button7 = Number(document.getElementById("buttons6").innerHTML); 
    var additionBruh7 = scorebox + button7;
    document.getElementById("score-box").innerHTML = additionBruh7;
}


function addition9() {
 var scorebox = Number(document.getElementById("score-box").innerHTML); 
     var button9 = Number(document.getElementById("buttons8").innerHTML); 
    var additionBruh9 = scorebox + button9;
    document.getElementById("score-box").innerHTML = additionBruh9;
}


function addition11() {
 var scorebox = Number(document.getElementById("score-box").innerHTML); 
     var button11 = Number(document.getElementById("buttons10").innerHTML); 
    var additionBruh11 = scorebox + button11;
    document.getElementById("score-box").innerHTML = additionBruh11;
}


function addition12() {
 var scorebox = Number(document.getElementById("score-box").innerHTML); 
     var button12 = Number(document.getElementById("buttons11").innerHTML); 
    var additionBruh12 = scorebox + button12;
    document.getElementById("score-box").innerHTML = additionBruh12;
}








